import React, { useState } from 'react';
import { 
  ClipboardPaste, 
  ArrowRight, 
  Link as LinkIcon, 
  CloudDownload, 
  AlertCircle,
  Play,
  X,
  Video,
  Music,
  Loader2
} from 'lucide-react';
import { API_BASE_URL } from './constants';
import { VideoInfo } from './types';

// --- Sub-components defined here for single-file simplicity and shared context ---

// 1. Input Panel
interface InputPanelProps {
  onUrlSubmit: (url: string) => void;
  error: string | null;
}

const InputPanel: React.FC<InputPanelProps> = ({ onUrlSubmit, error }) => {
  const [url, setUrl] = useState('');
  const [shake, setShake] = useState(false);

  const handleSubmit = () => {
    if (!url.trim()) {
      triggerError();
      return;
    }
    try {
      new URL(url);
      onUrlSubmit(url);
    } catch (_) {
      triggerError();
    }
  };

  const triggerError = () => {
    setShake(true);
    setTimeout(() => setShake(false), 500);
  };

  const handlePaste = async () => {
    try {
      const text = await navigator.clipboard.readText();
      setUrl(text);
    } catch (err) {
      console.error('Failed to read clipboard', err);
    }
  };

  return (
    <div className={`glass-panel p-3 rounded-3xl transition-all duration-500 ease-out ${shake ? 'animate-[shake_0.5s_cubic-bezier(.36,.07,.19,.97)_both]' : ''}`}>
      {/* Input Field */}
      <div className="relative group">
        <input 
          type="text" 
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSubmit()}
          placeholder="Paste your link here" 
          className="w-full bg-[#F2F2F2] text-gray-900 placeholder:text-gray-500 text-lg py-4 pl-6 pr-14 rounded-2xl outline-none focus:ring-2 focus:ring-indigo-500/20 focus:bg-white transition-all shadow-inner" 
          autoComplete="off" 
        />
        <button 
          className="absolute right-3 top-1/2 -translate-y-1/2 p-2 text-gray-400 hover:text-gray-700 hover:bg-black/5 rounded-xl transition-colors" 
          onClick={handlePaste}
        >
          <ClipboardPaste className="w-5 h-5" />
        </button>
      </div>

      {/* Action Buttons */}
      <div className="grid grid-cols-[1fr_auto_auto] gap-2 mt-2">
        <button 
          onClick={handleSubmit} 
          className="bg-white/5 hover:bg-white/10 active:bg-white/5 text-white border border-white/10 h-14 rounded-2xl font-medium text-lg transition-all flex items-center justify-center gap-2 group shadow-lg shadow-black/20"
        >
          <span>Download</span>
          <ArrowRight className="w-5 h-5 opacity-0 -ml-4 group-hover:opacity-100 group-hover:ml-0 transition-all duration-300" />
        </button>
        
        <button className="w-14 h-14 flex items-center justify-center bg-white/5 hover:bg-white/10 border border-white/10 rounded-2xl text-gray-400 hover:text-white transition-all" title="Supported Sites">
          <LinkIcon className="w-5 h-5" />
        </button>
        
        <button className="w-14 h-14 flex items-center justify-center bg-white/5 hover:bg-white/10 border border-white/10 rounded-2xl text-gray-400 hover:text-white transition-all" title="Saved Downloads">
          <CloudDownload className="w-5 h-5" />
        </button>
      </div>
      
      {/* Error Message */}
      {error && (
        <div className="mt-3 px-4 text-red-400 text-sm font-medium flex items-center gap-2 animate-[fadeIn_0.4s_ease-out_forwards]">
          <AlertCircle className="w-4 h-4" />
          <span>{error}</span>
        </div>
      )}
    </div>
  );
};

// 2. Loading Panel
const LoadingPanel: React.FC = () => {
  return (
    <div className="py-12 flex flex-col items-center justify-center glass-panel rounded-3xl mt-4 animate-[fadeIn_0.4s_ease-out_forwards]">
      <div className="relative w-12 h-12 mb-4">
        <div className="absolute inset-0 border-t-2 border-indigo-500 rounded-full animate-spin"></div>
        <div className="absolute inset-0 border-t-2 border-indigo-500/30 rounded-full blur-[2px]"></div>
      </div>
      <p className="text-gray-400 font-medium animate-pulse">Fetching metadata...</p>
    </div>
  );
};

// 3. Result Panel
interface ResultPanelProps {
  data: VideoInfo;
  sourceUrl: string;
  onReset: () => void;
}

const ResultPanel: React.FC<ResultPanelProps> = ({ data, sourceUrl, onReset }) => {
  const [selectedFormat, setSelectedFormat] = useState<string | null>(null);
  const [isDownloading, setIsDownloading] = useState(false);
  const [downloadStatus, setDownloadStatus] = useState<string>("Download Now");

  const formatFileSize = (bytes: number | null) => {
    if (!bytes) return 'Unknown size';
    const mb = bytes / (1024 * 1024);
    return `${mb.toFixed(1)} MB`;
  };

  const handleDownload = async () => {
    if (!selectedFormat) return;

    // Safety check for backend configuration
    if (API_BASE_URL.includes("YOUR-RENDER-URL")) {
        alert("Configuration Error: Please update the API_BASE_URL in constants.ts to your deployed Render URL.");
        return;
    }

    setIsDownloading(true);
    setDownloadStatus("Starting...");

    try {
      const response = await fetch(`${API_BASE_URL}/download`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          url: sourceUrl,
          format_id: selectedFormat
        })
      });

      if (!response.ok) throw new Error("Download failed");

      // Backend returns a binary file (send_file)
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      
      // Create temporary link to trigger download
      const a = document.createElement("a");
      a.href = url;
      a.download = `video-${Date.now()}.mp4`; // Matches backend .mp4 extension
      document.body.appendChild(a);
      a.click();
      a.remove();
      
      // Cleanup
      window.URL.revokeObjectURL(url);
      
      setDownloadStatus("Done!");
    } catch (err) {
      console.error(err);
      setDownloadStatus("Failed");
    } finally {
      setTimeout(() => {
        setIsDownloading(false);
        setDownloadStatus("Download Now");
      }, 3000);
    }
  };

  return (
    <div className="glass-panel p-6 rounded-3xl mt-4 animate-[fadeIn_0.4s_ease-out_forwards]">
      <div className="flex items-start justify-between mb-6 border-b border-white/5 pb-4">
        <div className="flex gap-4">
          <div className="w-16 h-16 bg-gray-800 rounded-xl overflow-hidden relative shadow-lg group">
            <img src={data.thumbnail} className="w-full h-full object-cover opacity-80 group-hover:scale-110 transition-transform duration-500" alt="Thumbnail" />
            <div className="absolute inset-0 flex items-center justify-center bg-black/20">
              <Play className="w-6 h-6 text-white fill-current" />
            </div>
          </div>
          <div>
            <h3 className="text-white font-medium text-lg tracking-tight line-clamp-1">{data.title}</h3>
            <p className="text-gray-500 text-sm mt-1">{Math.floor(data.duration / 60)} min • Source</p>
          </div>
        </div>
        <button onClick={onReset} className="text-gray-500 hover:text-white transition-colors bg-white/5 hover:bg-white/10 p-2 rounded-lg">
          <X className="w-5 h-5" />
        </button>
      </div>

      <div className="space-y-6">
        {/* Format Type Toggle (Visual only for now, can be extended to filter formats) */}
        <div>
          <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-3 block pl-1">Select Format</label>
          <div className="grid grid-cols-2 gap-2 p-1 bg-black/20 rounded-xl border border-white/5">
            <button className="flex items-center justify-center gap-2 py-2.5 rounded-lg bg-white/10 text-white shadow-sm ring-1 ring-white/10 transition-all">
              <Video className="w-4 h-4" />
              <span className="text-sm font-medium">Video</span>
            </button>
            <button className="flex items-center justify-center gap-2 py-2.5 rounded-lg hover:bg-white/5 text-gray-400 hover:text-white transition-all">
              <Music className="w-4 h-4" />
              <span className="text-sm font-medium">Audio</span>
            </button>
          </div>
        </div>

        {/* Quality Options */}
        <div>
          <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-3 block pl-1">Quality</label>
          <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
            {data.formats.length === 0 ? (
                <p className="text-gray-500 text-sm italic p-2">No MP4 formats found.</p>
            ) : (
                data.formats.map((fmt) => (
                <label 
                    key={fmt.format_id}
                    onClick={() => setSelectedFormat(fmt.format_id)}
                    className={`flex items-center justify-between group cursor-pointer p-3 rounded-xl border transition-all ${
                    selectedFormat === fmt.format_id 
                        ? 'bg-white/10 border-indigo-500/50' 
                        : 'hover:bg-white/5 border-transparent hover:border-white/5'
                    }`}
                >
                    <div className="flex items-center gap-3">
                    <div className={`w-5 h-5 rounded-full border flex items-center justify-center transition-colors ${
                        selectedFormat === fmt.format_id ? 'border-indigo-500' : 'border-gray-600 group-hover:border-indigo-500'
                    }`}>
                        <div className={`w-2.5 h-2.5 rounded-full bg-indigo-500 transition-opacity ${
                        selectedFormat === fmt.format_id ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'
                        }`}></div>
                    </div>
                    <div className="flex flex-col">
                        <span className="text-gray-200 font-medium text-sm">{fmt.resolution || 'Unknown'} (MP4)</span>
                        <span className="text-gray-500 text-xs uppercase">{fmt.ext}</span>
                    </div>
                    </div>
                    <span className="text-xs font-medium text-gray-500 bg-white/5 px-2 py-1 rounded-md">
                        {formatFileSize(fmt.filesize)}
                    </span>
                </label>
                ))
            )}
          </div>
        </div>

        <button 
          className={`w-full font-semibold h-12 rounded-xl text-sm transition-all shadow-lg shadow-white/5 flex items-center justify-center gap-2
            ${!selectedFormat || isDownloading 
                ? 'bg-gray-700 text-gray-400 cursor-not-allowed opacity-75' 
                : 'bg-white text-black hover:bg-gray-200'
            }`}
          onClick={handleDownload}
          disabled={!selectedFormat || isDownloading}
        >
          {isDownloading && <Loader2 className="w-4 h-4 animate-spin" />}
          {downloadStatus}
        </button>
      </div>
    </div>
  );
};


// 4. Main App Container
export default function App() {
  const [viewState, setViewState] = useState<'input' | 'loading' | 'result'>('input');
  const [videoInfo, setVideoInfo] = useState<VideoInfo | null>(null);
  const [currentUrl, setCurrentUrl] = useState('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleUrlSubmit = async (url: string) => {
    // Safety check for backend configuration
    if (API_BASE_URL.includes("YOUR-RENDER-URL")) {
        alert("Configuration Error: Please update the API_BASE_URL in constants.ts to your deployed Render URL.");
        return;
    }

    setCurrentUrl(url);
    setViewState('loading');
    setErrorMsg(null);

    try {
      const res = await fetch(`${API_BASE_URL}/info`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url })
      });

      if (!res.ok) {
        throw new Error("Failed to fetch video info");
      }

      const data: VideoInfo = await res.json();
      setVideoInfo(data);
      setViewState('result');
    } catch (err) {
      console.error(err);
      setErrorMsg("Failed to fetch video metadata. Check the URL.");
      setViewState('input');
    }
  };

  const resetApp = () => {
    setViewState('input');
    setVideoInfo(null);
    setCurrentUrl('');
    setErrorMsg(null);
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen relative w-full">
        {/* Ambient Background Glows */}
        <div className="absolute top-[-20%] left-[-10%] w-[600px] h-[600px] bg-indigo-600/10 rounded-full blur-[120px] pointer-events-none"></div>
        <div className="absolute bottom-[-20%] right-[-10%] w-[500px] h-[500px] bg-blue-600/10 rounded-full blur-[100px] pointer-events-none"></div>
        <div className="absolute top-[20%] left-[50%] -translate-x-1/2 w-[800px] h-[400px] bg-slate-800/20 rounded-[100%] blur-[80px] pointer-events-none"></div>

        <main className="w-full max-w-3xl px-6 relative z-10 flex flex-col items-center">
            
            {/* Header Text */}
            <div className="text-center mb-10 md:mb-14 space-y-4">
                <h1 className="text-5xl md:text-6xl font-semibold tracking-tight text-white bg-clip-text text-transparent bg-gradient-to-b from-white via-white to-white/60 pb-2">
                    Paste a link. Get<br/>the download.
                </h1>
                <p className="text-lg md:text-xl text-gray-500 max-w-lg mx-auto font-medium leading-relaxed">
                    We support links from Twitter, Instagram, TikTok, YouTube, Facebook and more
                </p>
            </div>

            {/* Main Interface Card */}
            <div className="w-full max-w-2xl mx-auto">
                {viewState === 'input' && (
                    <InputPanel onUrlSubmit={handleUrlSubmit} error={errorMsg} />
                )}

                {viewState === 'loading' && (
                    <LoadingPanel />
                )}

                {viewState === 'result' && videoInfo && (
                    <ResultPanel 
                        data={videoInfo} 
                        sourceUrl={currentUrl} 
                        onReset={resetApp} 
                    />
                )}
            </div>

            {/* Footer */}
            <footer className="mt-20 text-center">
                <p className="text-gray-600 text-sm">© 2024 LinkDownloader. No cookies, no logs.</p>
                <div className="flex justify-center gap-6 mt-4 opacity-50">
                    <div className="hover:text-white transition-colors cursor-pointer">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-5 h-5"><path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z"></path></svg>
                    </div>
                    <div className="hover:text-white transition-colors cursor-pointer">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-5 h-5"><path d="M9 19c-5 1.5-5-2.5-7-3m14 6v-3.87a3.37 3.37 0 0 0-.94-2.61c3.14-.35 6.44-1.54 6.44-7A5.44 5.44 0 0 0 20 4.77 5.07 5.07 0 0 0 19.91 1S18.73.65 16 2.48a13.38 13.38 0 0 0-7 0C6.27.65 5.09 1 5.09 1A5.07 5.07 0 0 0 5 4.77a5.44 5.44 0 0 0-1.5 3.78c0 5.42 3.3 6.61 6.44 7A3.37 3.37 0 0 0 9 18.13V22"></path></svg>
                    </div>
                    <div className="hover:text-white transition-colors cursor-pointer">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-5 h-5"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg>
                    </div>
                </div>
            </footer>
        </main>
        
        {/* CSS for custom Shake animation since it is specific to this app */}
        <style>{`
          @keyframes shake {
            10%, 90% { transform: translate3d(-1px, 0, 0); }
            20%, 80% { transform: translate3d(2px, 0, 0); }
            30%, 50%, 70% { transform: translate3d(-4px, 0, 0); }
            40%, 60% { transform: translate3d(4px, 0, 0); }
          }
        `}</style>
    </div>
  );
}