// Replace this URL with your actual Render backend URL
export const API_BASE_URL = "https://YOUR-RENDER-URL"; 
