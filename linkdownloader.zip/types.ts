export interface VideoFormat {
  format_id: string;
  ext: string;
  resolution: string | null;
  filesize: number | null;
}

export interface VideoInfo {
  title: string;
  duration: number; // in seconds
  thumbnail: string;
  formats: VideoFormat[];
}

export interface ApiError {
  error: string;
}
